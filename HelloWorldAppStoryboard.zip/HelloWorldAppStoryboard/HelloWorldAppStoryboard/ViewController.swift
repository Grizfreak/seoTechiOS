//
//  ViewController.swift
//  HelloWorldAppStoryboard
//
//  Created by com323_12 on 02/03/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

